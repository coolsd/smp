<?php

namespace Pagekit\Auth\Event;

class LogoutEvent extends GetResponseEvent
{
}
