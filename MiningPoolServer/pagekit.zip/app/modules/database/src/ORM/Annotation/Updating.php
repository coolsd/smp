<?php

namespace Pagekit\Database\ORM\Annotation;

/**
 * @Annotation
 * @Target("METHOD")
 */
final class Updating implements Annotation
{
}
